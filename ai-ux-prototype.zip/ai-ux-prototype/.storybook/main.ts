import type { StorybookConfig } from "storybook";

const config: StorybookConfig = {
  stories: ["../stories/**/*.stories.@(js|jsx|ts|tsx)"],
  addons: ["@storybook/addon-essentials", "@storybook/addon-a11y"],
  framework: {
    name: "@storybook/react",
    options: {}
  },
  docs: { autodocs: "tag" }
};
export default config;